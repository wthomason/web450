/*
=====================================
  ; Title: cumulative-summary.component.ts
  ; Author: William Thomason
  ; Date: September 29 2019
  ; Description: cumulative-summary.component.ts
======================================
*/

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cumulative-summary',
  templateUrl: './cumulative-summary.component.html',
  styleUrls: ['./cumulative-summary.component.css']
})
export class CumulativeSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
